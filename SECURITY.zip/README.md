Basic-Banking-System

Sparks Foundation Web Development Internship Project :

This project is a part of the Graduate Rotational Internship Program (GRIP) by The Sparks Foundation. The Sparks Foundation is a non-profit organization that aims to inspire students to innovate and build skills to solve real-life problems. The GRIP program is a 1-month internship program that provides hands-on experience in the field of web development and design & many more.

Basic Banking System website. A web application used to tranfer virtual money between multiple users and also record the banking transactions/ activities.  
The website has the following specification - Start with a dummy data for upto 10 customers. Customers table with basic fields such as name, email, current balance etc.
Transaction status: Transfer table/ Transfer History which records all the transactions  
Flow : Home Page > View all customers > Select and View one customer > Transfer Money > Select customer to transfer to > View all Customers.

If you have any questions or want to know more about the project, you can reach out to the creator, Kumar Gaurav, on LinkedIn at: https://www.linkedin.com/in/kgaurav152/

# Basic_Banking_System
